export class EmployeeDetails {
    EmployeeId:number;
    FirstName:string;
    LastName:string;
    Email:string;
    MobileNo:string;
    Address:string;
    PineCode:string;
}
