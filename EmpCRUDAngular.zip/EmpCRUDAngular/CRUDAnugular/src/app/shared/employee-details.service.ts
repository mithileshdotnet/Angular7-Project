import { Injectable } from '@angular/core';
import { EmployeeDetails } from './employee-details.model';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService {
formData:EmployeeDetails;
readonly rootURL = 'http://localhost:60249/api';
list : EmployeeDetails[];

constructor(private http: HttpClient) { }

postEmployeeDetail() {
  return this.http.post(this.rootURL + '/EmployeeAPI/InsertEmpDetails', this.formData);
}
putEmployeeDetail() {
  return this.http.put(this.rootURL + '/EmployeeAPI/UpdateEmpDetails/'+ this.formData.EmployeeId, this.formData);
}
deleteEmployeeDetail(id) {
  return this.http.delete(this.rootURL + '/EmployeeAPI/DeleteEmp/'+ id);
}

EmployeeList(){
  this.http.get(this.rootURL + '/EmployeeAPI/AllEmployeeDetails')
  .toPromise()
  .then(res => this.list = res as EmployeeDetails[]);
}
}
