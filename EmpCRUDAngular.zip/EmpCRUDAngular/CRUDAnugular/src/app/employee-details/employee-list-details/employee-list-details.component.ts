import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { EmployeeDetailsService } from 'src/app/shared/employee-details.service';
import { EmployeeDetails } from 'src/app/shared/employee-details.model';

@Component({
  selector: 'app-employee-list-details',
  templateUrl: './employee-list-details.component.html',
  styles: []
})
export class EmployeeListDetailsComponent implements OnInit {
  constructor(private service: EmployeeDetailsService,
    private toastr: ToastrService) { }

  ngOnInit() {
    this.service.EmployeeList();
  }

  editForm(a: EmployeeDetails) {
    this.service.formData = Object.assign({}, a);
  }

  empDelete(EmpId) {
    if (confirm('Are you sure to delete this record ?')) {
      this.service.deleteEmployeeDetail(EmpId)
        .subscribe(res => {
          debugger;
          this.service.EmployeeList();
          this.toastr.warning('Employee details Deleted successfully', 'Employee Detail Register');
        },
          err => {
            debugger;
            console.log(err);
          })
    }
  }

}
