import { Component, OnInit } from '@angular/core';

import { EmployeeDetailsService } from 'src/app/shared/employee-details.service';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-employee-register-details',
  templateUrl: './employee-register-details.component.html',
  styles: []
})
export class EmployeeRegisterDetailsComponent implements OnInit {

  constructor(private service:EmployeeDetailsService,private toastr: ToastrService) { }

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null)
      form.form.reset();
    this.service.formData = {
      EmployeeId:0,
      FirstName:'',
      LastName:'',
      Email:'',
      MobileNo:'',
      Address:'',
      PineCode:''
    }
  }

  onSubmit(form: NgForm) {
    if (this.service.formData.EmployeeId == 0)
      this.insertRecord(form);
    else
      this.updateRecord(form);
  }

  insertRecord(form: NgForm) {
    this.service.postEmployeeDetail().subscribe(
      res => {
        debugger;
        this.resetForm(form);
        this.toastr.success('Submitted successfully', 'Employee Detail Register');
        this.service.EmployeeList();
      },
      err => {
        debugger;
        console.log(err);
      }
    )
  }
  updateRecord(form: NgForm) {
    this.service.putEmployeeDetail().subscribe(
      res => {
        this.resetForm(form);
        this.toastr.info('Updated successfully', 'Employee Detail Register');
        this.service.EmployeeList();
      },
      err => {
        console.log(err);
      }
    )
  }

}
