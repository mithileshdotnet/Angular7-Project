﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPICURDs.Models;

namespace WebAPICURDs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeAPIController : ControllerBase
    {
        private readonly EmployeeDbContext _context;

        public EmployeeAPIController(EmployeeDbContext context)
        {
            _context = context;
        }

       

        [HttpGet]
        [Route("AllEmployeeDetails")]
        public async Task<ActionResult<IEnumerable<Employee>>> GetEmployeeDetails()
        {
            return await _context.employee.ToListAsync();
        }


        [HttpPut]
        [Route("UpdateEmpDetails/{id}")]
        public async Task<IActionResult> UpdateEmpDetails([FromRoute] int id, [FromBody] Employee employees)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != employees.EmployeeId)
            {
                return BadRequest();
            }

            _context.Entry(employees).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmpDetailsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpPost]
        [Route("InsertEmpDetails")]
        public async Task<IActionResult> PostEmployeeDetails([FromBody] Employee employees)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                _context.employee.Add(employees);
                await _context.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                ex.ToString();
            }

            return CreatedAtAction("GetEmployeeDetails", new { id = employees.EmployeeId }, employees);
        }

        [HttpDelete("DeleteEmp/{id}")]
        public async Task<IActionResult> DeleteEmpDetails([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var empDetails = await _context.employee.FindAsync(id);
            if (empDetails == null)
            {
                return NotFound();
            }

            _context.employee.Remove(empDetails);
            await _context.SaveChangesAsync();

            return Ok(empDetails);
        }

        private bool EmpDetailsExists(int id)
        {
            return _context.employee.Any(e => e.EmployeeId == id);
        }

    }
}